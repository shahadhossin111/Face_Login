from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('pages', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='database',
            name='headshot',
            field=models.ImageField(blank=True, upload_to='author_headshots'),
        ),
    ]