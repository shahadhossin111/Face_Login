from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('pages', '0004_auto_20181024_1815'),
    ]

    operations = [
        migrations.AlterField(
            model_name='userprofile',
            name='head_shot',
            field=models.ImageField(blank=True, upload_to='profil_images'),
        ),
    ]